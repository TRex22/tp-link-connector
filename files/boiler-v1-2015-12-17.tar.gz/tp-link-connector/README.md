# tp-link-connector
A node package to connect to tp-link routers, and perhaps switches.
