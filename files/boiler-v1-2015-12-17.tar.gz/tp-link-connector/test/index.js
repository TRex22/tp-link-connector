var should = require('chai').should();
//var assert = require("assert");

var fs = require('fs');
var xl = require('excel4node');
var util = require('util');

describe('#tp-link-connect', function() {
  it('connectsToRouterReturnsRouterStatus', function(){
    //do stuff
  });

});
